
// OBJETIVO
/**
 * Criar variaveis e usá-las para modificar a DOM
 */
const titulo = document.getElementById("titulo");
const paragrafo = document.getElementById("paragrafo");

//MINHAS VARIAVEIS
const novoTitulo = "Título modificado";
const novoParagrafo = "Parágrafo modificado";

titulo.innerText = novoTitulo
paragrafo.innerText = novoParagrafo


//ARRAYS SÃO ORGANIZADOS POR INDICES (A PARTIR DO 0)
// (), [], {}
const roupa = 'camisa'
const roupas = ['camisa', 'calça', 'moletom', 'shorts']
//INDICES         0         1         2           3    
const precos = [80, 150, 200, 60]
const idades = [10, 20, 30, 40]
const misto = ['manga', '15', 'carro', 'brawl', false]
// ACESSAR UM ELEMENTO DO ARRAY
//console.log(roupa)
//console.log(roupas)
//console.log(roupas[4])
//roupas[20] = "sorvete"
//console.log(roupas[20])

for (var i = 0; i <= 3; i++) {
  // lógica
  console.log(roupas[i])
}
for (var j = 0; j <= 3; j++) {
  // logica imprimindo os preços
  console.log(precos[j])
}



