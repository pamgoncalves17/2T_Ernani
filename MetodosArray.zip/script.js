//METODOS DE ARRAY
const comidas = ['churrascada', 'pizza']
comidas[3] = 'sushi' //MANUAL
comidas.push('beringela') //EMPURRANDO UM VALOR PARA O FINAL DA LISTA
comidas.pop() //REMOVENDO UM VALOR DO FINAL DA LISTA
comidas.shift() //REMOVENDO UM VALOR DO INICIO DA LISTA
comidas.unshift('mamão') // INSERIR UM ITEM NO INICIO DA LISTA

console.log(comidas.length) // CONTAGEM DOS ITENS
const tamanho = comidas.length
console.log("existem " + tamanho + " itens na lista") // CONTAGEM DO ITENS

console.log(comidas)