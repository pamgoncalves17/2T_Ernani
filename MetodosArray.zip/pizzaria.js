let sabores = [] // CRIAR UM ARRAY VAZIO
let pedidos = 0


const cliente = prompt("Olá, qual seu nome? ")
// CHECAR COM IF SE O NOME DO USUARIO EXISTE
if(cliente) {
  alert("Olá " + cliente + ", seja bem vindo(a)!")

  // LOOPDE REPETIÇÃO INFINO (QUE RODA ENQUANTO UMA CONDIÇÃO FOR VERDADEIRA))
  while (pedidos < 3) {
    let sabor = prompt("🍕 Qual sabor você deseja? ")
    if (sabor) {
      sabores.push(sabor) // ENVIAR PARA NOSSA LISTA
      alert("Pedido recebido!")
      pedidos = pedidos + 1 // ACÚMULO DE VALORES 
    }
 }
   // IMPRIMIR LISTA
    alert("Pedido fechado com sucesso! Olhe seu log!")
    console.log("---------🍕 PIZZARIA CLÁSSICA 🍕----------")
    console.log(sabores)
    console.log("----------------------------------------------") 
} else {
  alert("Por favor, digite seu nome!")
}



