function dados(nome, sobrenome) {
  if (typeof nome === 'string' && typeof sobrenome === 'string') {
    const res = "Olá " + nome + " " + sobrenome + "!"
    alert(res)
  }
  else {
    alert("Digite seu nome corretamente!")
  }
}
// dados("Luiza", "Souza")
// dados(17, "Souza")

function dados(nome, altura) {
  if (typeof nome === 'string' && typeof altura === 'number') {
    const res = "Olá " + nome + " Sua altura é: " + altura + "!"
    alert(res)
  }
  else {
    alert("Digite seus dados corretamente!")
  }
}
// dados("Luiza", 1.65)
// dados(12, 100)

//CRIE UMA FUNCAO QUE RECEBA UM NÚMERO COMO PARAMETRO
/*
CASO (IF) N % 2 === 0, IMPRIMA "0 número" + NUMERO + " é par "
CASO CONTRARIO (ELSE), IMPRIMA "0 número" + NUMERO + " é impar"
*/

function parOuImpar(x){
  if(typeof x === 'number') {
    
 
  if ( x % 2 === 0) {
    alert('Olá, o número ' + x + ' é par!')
  } else{
    alert('Olá, o numero ' + x + ' é impar!')
  }
  } else {
    alert('Por favor, insira um número válido!')
      
  }
}
parOuImpar(8)
parOuImpar(11)
parOuImpar("Uva")