// FUNÇOẼS COM RETURNO
// SÃO FUNÇOẼS QUE PERMITEM RETER O VALOR PROCESSADO PARA USO POSTERIOR

// const nome = 'manuelly'
// function retornaDados() {
//   // código com retorno
//   return nome.toUpperCase()
//   console.log('testando...') //INALCANÇAVEL
//   //A PARTIR DESSA LINHA NÃO EXECUTA MAIS NADA...
// }
// const dados = retornaDados()
// alert(dados)

/**
 * CRIE UMA FUNÇÃO QUE RECEBA (nome, idade, cpf)
 * RETORNE OS DADOS FORMATADOS COM UMA MENSAGEM COM TODOS OS DADOS
 * ARMAZENE EM UMA VARIAVEL E IMPRIMA COM CONSOLE.LOG()
 */

const nome = 'Manuelly'
const idade = 17
const cpf = '123.456.789-00'
function retornaDados(nome, idade, cpf) {
  return 'Olá, ' + nome + ' sua idade é ' + idade + ' e seu cpf é ' + cpf

}
const dados = retornaDados('Manuelly', 17, '123.456.789-00')
alert(dados)