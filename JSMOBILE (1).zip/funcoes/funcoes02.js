// // DECLARAÇÃO OU CRIAÇÃO
// function soma (n1, n2) {
//   if(typeof n1 === 'number' && typeof n2 === 'number'){
//     const res = n1 + n2;
//     alert('0 resultado foi: ' + res)
//   }else {
//     alert('Por favor insira um número válido')
//   }
// }
// //INOVAÇÃO OU CHAMAR
// soma("uva",5)
// soma(50,50)
// soma(15,15)
// soma(2,1)

 function dados(nome, altura){
   
   if (typeof nome === 'string' && typeof altura === 'number') {
     const res = 'Olá ' + nome + ' sua altura é ' + altura
     alert(res) 
     }else {alert('Por favor, insira seus dados corretamente!')}
  
    } 
      


   dados('Pamella', 1.69)
   dados(17, 1.60)

 